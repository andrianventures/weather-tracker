
import { WeatherStore } from '../types';

const STORAGE_KEY = 'weather_tracker_2026_data';

export const saveRecords = (records: WeatherStore) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
};

export const loadRecords = (): WeatherStore => {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : {};
};
